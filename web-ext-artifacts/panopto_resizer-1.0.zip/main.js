const MOVELEFT_KEY = "KeyA";
const MOVERIGHT_KEY = "KeyD";
const STEP = 10;

let screen_ratio = 50;

let body = document.getElementsByTagName("body")[0];
let asides = document.getElementsByTagName("aside");
let viewerContent = document.getElementById("viewerContent");
let toggleThumbnailsButton = document.getElementById("toggleThumbnailsButton");

//Left side
let leftPane = document.getElementById("leftPane");
let leftPlayerContainer = document.getElementById("leftPlayerContainer");
let primaryPlayer = document.getElementById("primaryPlayer");
let primaryScreen = document.getElementById("primaryScreen");

//Right side
let playControlsWrapper = document.getElementById("playControlsWrapper");
let thumbnailList = document.getElementById("thumbnailList");
let secondaryContents = document.getElementsByClassName("secondary-content");
let rightPlayersContainer = document.getElementById("rightPlayersContainer");
// let secondaryScreen = document.getElementById("secondaryScreen");


function hide_asides() {
    for (let aside of asides) {
        aside.style.display = "none";
    }
}

function set_left_side_height() {
    height = viewerContent.style.height;
    for (let htmlElement of [leftPlayerContainer, primaryPlayer]) {
        htmlElement.style.height = height;
    }
}

function set_video_screen_to_adjust(htmlElement) {
    htmlElement.style.marginTop = 0;
    htmlElement.style.marginLeft = 0;
    htmlElement.style.left = 0;
    htmlElement.style.top = 0;
    htmlElement.style.width = "100%";
    htmlElement.style.height = "100%";
}

function set_right_side_width(width) {
    let secondaryScreen = document.getElementById("secondaryScreen");
    set_video_screen_to_adjust(secondaryScreen);
    for (htmlElement of [playControlsWrapper, thumbnailList, rightPlayersContainer, ...secondaryContents]) {
        htmlElement.style.width = `${width}px`
    }
}

function set_left_side_width(width) {
    hide_asides();
    set_left_side_height();
    set_video_screen_to_adjust(primaryScreen);
    leftPane.style.maxWidth = `${width}px`;
    for (htmlElement of [leftPane, leftPlayerContainer, primaryPlayer]) {
        htmlElement.style.width = `${width}px`;
    }
}

function set_screen_ratio(screen_ratio) {
    totalWidth = window.visualViewport.width;
    leftWidth = totalWidth * screen_ratio * 0.01;
    rightWidth = totalWidth * (100 - screen_ratio) * 0.01;
    set_left_side_width(leftWidth);
    set_right_side_width(rightWidth);
}

function reset_screen_ratio() {
    set_screen_ratio(screen_ratio);
}

function change_screen_ratio_in_direction(direction) {
    raw_screen_ratio = screen_ratio + (direction * STEP);
    boundary_list = [0, raw_screen_ratio, 100];
    boundary_list.sort((a, b) => a - b);
    screen_ratio = boundary_list[1];
    set_screen_ratio(screen_ratio);
}

function key_down(e) {
    switch (e.code) {
        case MOVELEFT_KEY:
            change_screen_ratio_in_direction(-1);
            break;
        case MOVERIGHT_KEY:
            change_screen_ratio_in_direction(1);
            break;
        default:
            return;
    }
}

// document.body.style.border = "5px solid red";
// document.body.innerHTML = screen_ratio;
body.addEventListener("keydown", key_down);
body.addEventListener("resize", reset_screen_ratio);
toggleThumbnailsButton.addEventListener("click", reset_screen_ratio);
